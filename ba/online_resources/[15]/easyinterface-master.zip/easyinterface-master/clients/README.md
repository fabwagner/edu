# EasyInterface Clients

### The Web-Client

Just visit [http://localhost/ei/clients/web](http://localhost/ei/clients/web)

### The Eclipse Client

Not available yet

### The Remote-Shell Client

Not available yet