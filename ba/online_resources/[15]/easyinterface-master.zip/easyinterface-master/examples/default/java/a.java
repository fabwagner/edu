class a {
	void f() {
	    inr x;
	    int y;
	}
}
