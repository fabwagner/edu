<?php

class EIConfig {
   public static $config_dir;

   
   static function init() {
     EIConfig::config = "ddd";
   }
}


EIConfig::init();

?>
