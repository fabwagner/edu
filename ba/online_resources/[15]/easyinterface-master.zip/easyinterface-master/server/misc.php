<?php


// print a string followed by a new line
//
function println($s) {
  if ($s != "")
    printf("%s\n",$s);
}



?>

