# EasyInterface Server

This directory includes the PHP scripts that implement the EasyInterface server. Communicating with the server is done through POST requests. Such request must include an entry called `eirequest` whose value is a JSON object that describes the request.

## EI Request Syntax

TBD
